namespace much {
//too long locomotive......
#define V void
#define I_16 short
#define I_32 int
#define I_64 long long
#define _B bool
#define D double
#define C char
#define STR std::string
#define Vector std::vector
#define _T true
#define _F false
#define _R return
#define mPI 3.1415926535
#define mE 2.71828182845
#define caria(r) (mPI * r * r)
#define mset(a, n) memset(a, n, sizeof(a))
#define mdst(x1, y1, x2, y2) sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2))
#define _rep(i, a, b) for (i = a; i <= b; i++)
#define _for(i, a, b) for (i = a; i < b; i++)
#if __cplusplus >= 201103L
	#define _range_for(i, _range) for (auto i : _range)
#endif
}
